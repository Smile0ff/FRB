(function($, root){

	"use strict";

	function PreLoaderController(){
		this.el = $("#preloader-holder");
		this.initialize.apply(this, arguments);
	}
	PreLoaderController.prototype = {
		frbCube: [],
		loadTime: 5500,
		initialize: initialize,
		_events: _events,
		handleLoad: handleLoad
	}

	function initialize(){
		this._events();
		this.frbCube = $("#frb-cube-holder");
	}
	function _events(){
		$(root).on("load", $.proxy(this.handleLoad, this));
	}
	function handleLoad(e){
		var self = this;

		root.setTimeout(function(){
			self.el.addClass("loaded");
			self.frbCube.addClass("loaded");
		}, this.loadTime);
	}

	module.exports = PreLoaderController;

})(jQuery, window);