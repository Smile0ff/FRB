(function($, root){

	"use strict";

	function MenuController(){
		this.el = $("#menu-holder");
		this.initialize.apply(this, arguments);
	}
	MenuController.prototype = {
		menuButton: [],
		initialize: initialize,
		_events: _events,
		handleMenu: handleMenu
	}

	function initialize(){
		this.menuButton = $("#toggle-menu");
		this._events();
	}
	function _events(){
		this.menuButton.on("click", $.proxy(this.handleMenu, this));
	}
	function handleMenu(e){
		e.preventDefault();

		this.el.toggleClass("active");
		this.menuButton.toggleClass("active");
	}

	module.exports = MenuController;

})(jQuery, window);