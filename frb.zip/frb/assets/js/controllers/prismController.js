(function($, root){

	"use strict";

	var vendorFilter = require("../filters/vendorFilter"),
		PrismBuilder = require("../lib/PrismBuilder"),
		transform;

	transform = vendorFilter("transform");

	function PrismController(){
		this.el = $("#prism");
		this.initialize.apply(this, arguments);
	}
	PrismController.prototype = {
		prismBuilder: {},
		stateHolder: [],
		menuHolder: [],
		current: 0,
		state: 0,
		isRotating: false,
		initialize: initialize,
		_events: _events,
		handleState: handleState,
		updateCurrent: updateCurrent,
		updateState: updateState,
		rotatePrism: rotatePrism,
		changeState: changeState,
		stateChanged: stateChanged
	}

	function initialize(){
		this.prismBuilder = new PrismBuilder();
		this.stateHolder = $("#prism-state-holder");
		this.menuHolder = $("#menu-holder");

		this._events();
	}
	function _events(){
		this.el.on("webkitTransitionEnd transitionend msTransitionEnd oTransitionEnd", $.proxy(this.stateChanged, this));
		this.stateHolder.on("click", ".arrow", $.proxy(this.handleState, this));
	}
	function handleState(e){
		e.preventDefault();
		if(this.isRotating) return;

		var target = $(e.target).closest(".arrow");
		
		this.updateCurrent(target);
		this.updateState(target);

		this.rotatePrism();
		this.changeState()
	}
	function updateCurrent(target){
		target.hasClass("up") ? this.current++ : this.current--;
	}
	function updateState(target){
		target.hasClass("up") ? this.state-- : this.state++;

		if(this.state < 0){
			this.state = 3;
		} else if(this.state > 3){
			this.state = 0;
		}
	}
	function rotatePrism(){
		this.isRotating = true;
		this.el.css({transform: "translateZ("+ this.prismBuilder.deep.y * -1 +"px) rotateX("+ this.current * 90 +"deg)"});
	}
	function changeState(){
		var state = Math.abs(this.state);
		
		this.stateHolder.removeClass().addClass("state-" + state);
		this.menuHolder.removeClass().addClass("in-intro state-" + state);
	}
	function stateChanged(){
		this.isRotating = false;
	}

	module.exports = PrismController;

})(jQuery, window);