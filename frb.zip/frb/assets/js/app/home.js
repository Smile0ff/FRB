(function(root){

	"use strict";

	root.jQuery = root.$ = require("jquery");
	
	require("jquery-ui");
	require("jquery-validation");

	var PreLoaderController = require("../controllers/PreLoaderController"),
		PrismController = require("../controllers/prismController"),
		MenuController = require("../controllers/MenuController");
	
	new PreLoaderController();

	$(function(){
		new PrismController();
		new MenuController();
	});

})(window);