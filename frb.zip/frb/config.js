(function(){

	"use strict";

	var _config = {
		baseDir: "",
		jsDir: "assets/js/",
		cssDir: "assets/css/",
		fontsDir: "assets/fonts/",
		imgDir: "assets/images/",
		outDir: "build/"
	};

	module.exports = _config;

})();